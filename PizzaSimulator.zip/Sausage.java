public class Sausage
{
    Meat sausage;;
    public Sausage(){
        Money cost = new Money(4);
        sausage = new Meat("Sausage",cost,138);
    }
}