
/**
 * Write a description of class Olive here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */ 
public class Olive{
            Vegetable olive;
            Money cost = new Money(.65);
            public Olive(){
                olive = new Vegetable("Olives",cost,115);
            }
        }
