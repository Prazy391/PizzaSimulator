public class Goat{
            Cheese goat;
            public Goat(){
                Money cost = new Money(4);
                goat = new Cheese("Goat", cost,103); 
            }
        }