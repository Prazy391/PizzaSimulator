public class Mozzarella{
            Cheese mozzarella;
            public Mozzarella(){
               Money cost = new Money(4);
               mozzarella = new Cheese("Mozzarella",cost,78);
            }
        }