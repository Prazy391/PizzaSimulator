
/**
 * Write a description of class b here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Pepperoni
{
    Meat pepperoni;;
    public Pepperoni(){
        Money cost = new Money(4);
        pepperoni = new Meat("Pepperoni",cost,138);
    }
}
