public class Alfredo{
            Base alfredo;
            public Alfredo(){
               Money cost = new Money(4);
               alfredo = new Base("Alfredo",cost,208);
            }
        } 