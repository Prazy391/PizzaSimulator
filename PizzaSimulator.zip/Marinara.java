public class Marinara{
            Base marinara;
            public Marinara(){
               Money cost = new Money(4);
               marinara = new Base("Marinara",cost,65);
            }
        }